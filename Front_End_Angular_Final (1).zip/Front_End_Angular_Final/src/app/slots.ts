
export class Slots{
    
    id: number= 0;
    slotDate: Date | undefined;
    slotTime: string='';
    userName: string= '';
    centerName: string= '';
    vtype: string='';
    dose: string='';
    aadharNumber: number=0
}